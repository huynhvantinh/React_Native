import { FlatList } from 'react-native';

function ExpensesList() {
  return <FlatList />;
}

export default ExpensesList;