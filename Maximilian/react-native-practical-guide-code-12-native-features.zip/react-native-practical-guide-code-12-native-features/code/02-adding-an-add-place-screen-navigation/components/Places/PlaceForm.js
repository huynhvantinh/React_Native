import { Text, View } from 'react-native';

function PlaceForm() {
  return (
    <View>
      <Text>The Place Form</Text>
    </View>
  );
}

export default PlaceForm;
