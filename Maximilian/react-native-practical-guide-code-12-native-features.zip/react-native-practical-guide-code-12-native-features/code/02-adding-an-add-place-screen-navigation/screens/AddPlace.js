import PlaceForm from '../components/Places/PlaceForm';

function AddPlace() {
  return <PlaceForm />;
}

export default AddPlace;
