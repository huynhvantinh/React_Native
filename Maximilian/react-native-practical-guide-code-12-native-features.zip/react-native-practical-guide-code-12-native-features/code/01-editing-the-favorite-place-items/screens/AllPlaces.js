import PlacesList from '../components/Places/PlacesList';

function AllPlaces() {
  return <PlacesList />;
}

export default AllPlaces;
