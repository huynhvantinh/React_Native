import { Text } from 'react-native';

function GameScreen() {
  return <Text>Game Screen!</Text>
}

export default GameScreen;