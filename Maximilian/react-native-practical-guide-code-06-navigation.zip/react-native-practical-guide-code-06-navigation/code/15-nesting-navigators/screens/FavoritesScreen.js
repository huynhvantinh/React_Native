import { Text } from 'react-native';

function FavoritesScreen() {
  return <Text>The favorites screen!</Text>;
}

export default FavoritesScreen;
